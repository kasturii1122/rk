package stepDefinitions;

public class seleDefinition {

}
