package stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class ParallelDefinition {
WebDriver driver;
@Given("user on the site to test parallel")
public void user_on_the_site_to_test_parallel() throws InterruptedException {
	System.setProperty("webdriver.chrome.driver","C:\\\\verizon\\\\day2\\\\chromedriver.exe");
	driver=new ChromeDriver();
	Thread.sleep(3000);
}

@When("url is lauched{string} to test parallel")
public void url_is_lauched_http_www_amazon_in_to_test_parallel() throws InterruptedException {
	driver.navigate().to("https://www.makemytrip.com/");
	Thread.sleep(3000);
	driver.manage().window().maximize();
	Thread.sleep(3000);

}

@Then("close the site to test parallel")
public void close_the_site_to_test_parallel() {
	driver.close();

}




}
