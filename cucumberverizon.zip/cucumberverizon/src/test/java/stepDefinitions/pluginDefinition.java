package stepDefinitions;

public class pluginDefinition {

}
